Motivation Mate - Desktop Mascot
================================

Thank you for downloading Motivation Mate!

[How to Use]
1. Run "MotivationMate.exe".
2. You will see a mascot on your desktop.
3. Click the mascot to open Settings.
4. Enter your Gemini API Key.
   (You can get a free API key from Google AI Studio: https://aistudio.google.com/app/apikey)
5. Set your Goal (e.g., "Studying", "Working") and Feedback Interval.
6. The mascot will monitor your screen and encourage you!

[Troubleshooting]
- If notifications do not appear, fully quit the app from the System Tray (right-click MotiMate icon -> Exit) and restart.
- Ensure you have an active internet connection for the AI analysis.

[Credits]
Created by Motivation Mate Team.
Generated with Gemini.
